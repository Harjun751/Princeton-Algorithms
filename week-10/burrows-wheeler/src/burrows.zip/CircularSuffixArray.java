import edu.princeton.cs.algs4.BinaryStdIn;

import java.util.ArrayList;
import java.util.Collections;

public class CircularSuffixArray {
    private final ArrayList<String> suffixes;
    private final String[] sorted;

    private final int length;

    // circular suffix array of s
    public CircularSuffixArray(String s) {
        length = s.length();
        suffixes = new ArrayList<>();
        sorted = new String[s.length()];

        // create circular suffix array
        for (int i = 0; i < s.length(); i++) {
            String suffix = s.substring(i) + s.substring(0, i);
            suffixes.add(suffix);
        }

        ArrayList<String> sortedArrayList = new ArrayList<>(suffixes);

        Collections.sort(sortedArrayList);
        // sort the array of strings in lexical order
        int i = 0;
        for (String suf : sortedArrayList) {
            sorted[i] = suf;
            i++;
        }
    }

    // length of s
    public int length() {
        return length;
    }

    // returns index of ith sorted suffix
    public int index(int i) {
        // get string
        String o = sorted[i];
        return suffixes.indexOf(o);
    }

    // unit testing (required)
    public static void main(String[] args) {
        CircularSuffixArray csa = new CircularSuffixArray(BinaryStdIn.readString());
        System.out.println(csa.length);
        System.out.println(csa.index(11));
        System.out.println(csa.index(5));
        System.out.println(csa.index(6));
    }

}
