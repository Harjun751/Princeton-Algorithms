import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdRandom;

public class Permutation {
    public static void main(String[] args) {
        int k;
        if (args.length == 0) {
            k = 3;
        } else {
            k = Integer.parseInt(args[0]);
        }
        if (k==0){
            return;
        }
        RandomizedQueue<String> q = new RandomizedQueue<>();

        int counter = 0;
        while (!StdIn.isEmpty()) {
            String word = StdIn.readString();
            if (counter>=k){
                int r = StdRandom.uniformInt(0, counter);
                if (r < k-1){
                    // dequeue a random word
                    q.dequeue();
                    // enq this word
                    q.enqueue(word);
                }
            } else {
                q.enqueue(word);
            }
            counter++;
        }


        for (String str : q){
            System.out.println(str);
        }
    }
}