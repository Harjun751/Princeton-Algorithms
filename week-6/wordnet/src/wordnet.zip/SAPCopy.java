import edu.princeton.cs.algs4.DepthFirstOrder;
import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.algs4.SET;
import edu.princeton.cs.algs4.Stack;

public class SAPCopy {
    private Digraph graph;


    // constructor takes a digraph (not necessarily a DAG)
    public SAPCopy(Digraph G) {
        graph = new Digraph(G);
    }

    // length of shortest ancestral path between v and w; -1 if no such path
    public int length(int v, int w) {
        BreadthFirstSearch search = new BreadthFirstSearch(graph, v, w);
        return search.getDistance();
    }

    // a common ancestor of v and w that participates in a shortest ancestral path; -1 if no such path
    public int ancestor(int v, int w) {
        BreadthFirstSearch search = new BreadthFirstSearch(graph, v, w);
        return search.getAncestor();
    }

    // length of shortest ancestral path between any vertex in v and any vertex in w; -1 if no such path
    public int length(Iterable<Integer> v, Iterable<Integer> w) {
        BreadthFirstSearch search = new BreadthFirstSearch(graph, v, w);
        return search.getDistance();
    }

    // a common ancestor that participates in shortest ancestral path; -1 if no such path
    public int ancestor(Iterable<Integer> v, Iterable<Integer> w) {
        BreadthFirstSearch search = new BreadthFirstSearch(graph, v, w);
        return search.getAncestor();
    }

    // do unit testing of this class
    public static void main(String[] args) {
        In in = new In("inputs/digraph1.txt");
        Digraph G = new Digraph(in);
        SAPCopy sapCopy = new SAPCopy(G);
        sapCopy.ancestor(5, 7);
    }

    private class CC {
        private boolean marked[];
        private boolean onStack[];
        private int[] id;
        private int count;

        public CC(Digraph G) {
            marked = new boolean[G.V()];
            onStack = new boolean[G.V()];
            id = new int[G.V()];
            for (int i = 0; i < id.length; i++) {
                id[i] = -1;
            }
            this.count = 0;
            DepthFirstOrder dfs = new DepthFirstOrder(G);
            for (int v : dfs.reversePost()) {
                if (!marked[v]) {
                    dfs(G, v, -1);
                }
            }
        }

        public int dfs(Digraph g, int v, int previd) {
            // if node is already on stack at the start,
            // it means that there's a directed loop
            // break loop & return the previous id.

            // if the node is already marked
            if (marked[v] || onStack[v]) {
                // check if node doesn't have a set ID
                if (id[v] == -1) {
                    // Set the node's id
                    // check if the previous node already has an ID
                    if (previd == -1) {
                        // if don't have, increment ID - new tree
                        id[v] = count += 1;
                    }
                    else {
                        // if have, set it to the previous node
                        id[v] = previd;
                    }
                }
                // if has id, just return currid
                return id[v];
            }

            // add marked and onStack
            marked[v] = true;
            onStack[v] = true;

            int prevN = -1;
            int newId = -1;
            for (int x : g.adj(v)) {
                // search deeper & set id of current node
                if (previd != -1) {
                    newId = dfs(g, x, previd);
                }
                else {
                    prevN = x;
                    newId = dfs(g, x, id[v]);
                    if (prevN != -1) {
                        if (newId < prevN) {
                            id[prevN] = newId;
                        }
                        else {
                            newId = prevN;
                        }
                    }
                }
            }
            id[v] = newId;

            // this case is if there is no adjacent nodes
            // and it is an unmarked node (e.g. top of tree)
            if (id[v] == -1) {
                // set id to incremented count or
                // set id to previous id if exists
                if (previd == -1) {
                    id[v] = count += 1;
                }
                else {
                    id[v] = previd;
                }
            }
            // return the current id
            return id[v];
        }

        // private void dfs(Digraph G, int v) {
        //     marked[v] = true;
        //     id[v] = count;
        //     for (int w : G.adj(v))
        //         if (!marked[w])
        //             dfs(G, w);
        // }

        public boolean connected(int v, int w) {
            return id[v] == id[w];
        }
    }


    private class BreadthFirstSearch {

        private CC conQuery;
        private int[] edgeTo;

        private int ancestor = -1;

        private int[] id;

        private int distance = Integer.MAX_VALUE;


        public BreadthFirstSearch(Digraph g, int source, int goal) {
            Stack<Integer> sourceIter = new Stack<Integer>();
            Stack<Integer> goalIter = new Stack<Integer>();
            sourceIter.push(source);
            goalIter.push(goal);
            // pass the call to BFS
            this.bfs(g, sourceIter, goalIter);
        }

        public BreadthFirstSearch(Digraph g, Iterable<Integer> source, Iterable<Integer> goal) {
            // pass the call to BFS
            this.bfs(g, source, goal);
        }

        private void bfs(Digraph g, Iterable<Integer> source, Iterable<Integer> goal) {
            Digraph graph = new Digraph(g);
            conQuery = new CC(g);

            boolean[] marked = new boolean[g.V()];
            edgeTo = new int[g.V()];
            for (int i = 0; i < g.V(); i++) {
                edgeTo[i] = -1;
            }
            SET<Integer> goalSet = new SET<>();
            SET<Integer> srcSet = new SET<>();
            SET<Integer> vertexes = new SET<>();

            Queue<Integer> search = new Queue<>();
            int sourceUnreachableCount = 0;
            int goalUnreachableCount = 0;
            int sourceCount = 0;
            int goalCount = 0;

            for (int v : source) {
                // check if source is reachable
                if ((g.indegree(v) == 0 && g.outdegree(v) == 0)) {
                    sourceUnreachableCount += 1;
                }
                else {
                    search.enqueue(v);
                    marked[v] = true;
                }
                vertexes.add(v);
                srcSet.add(v);
                sourceCount += 1;
            }


            for (int v : goal) {
                boolean isConnected = true;

                for (int w : srcSet) {
                    if (!conQuery.connected(v, w)) {
                        isConnected = false;
                    }
                }

                if (!isConnected) {
                    goalUnreachableCount += 1;
                    goalCount += 1;
                    continue;
                }
                // check if the sources contain the exact same goal
                if (vertexes.contains(v)) {
                    // if source and goal are the same, we have found SAP.
                    this.distance = 0;
                    this.ancestor = v;
                    return;
                }

                // check if goal is reachable
                if ((g.indegree(v) == 0 && g.outdegree(v) == 0)) {
                    goalUnreachableCount += 1;
                }
                else {
                    // if reachable, add to search
                    search.enqueue(v);
                    vertexes.add(v);
                    marked[v] = true;
                    goalSet.add(v);
                }
                goalCount += 1;
            }

            if (goalUnreachableCount == goalCount || sourceUnreachableCount == sourceCount) {
                // if either SET of goals/sources are unreachable,
                // there is no path.
                this.distance = -1;
                this.ancestor = -1;
                return;
            }

            while (!search.isEmpty()) {
                int vertex = search.dequeue();

                for (int neighbour : graph.adj(vertex)) {
                    if (!marked[neighbour]) {
                        search.enqueue(neighbour);
                        marked[neighbour] = true;
                        edgeTo[neighbour] = vertex;
                    }
                    else {
                        if (vertexes.contains(neighbour)) {
                            // backtrack-check validity
                            if (srcSet.contains(neighbour)) {
                                int searchtex = vertex;
                                while (edgeTo[searchtex] != -1) {
                                    searchtex = edgeTo[searchtex];
                                }
                                if (!goalSet.contains(searchtex)) {
                                    if (this.ancestor == -1) {
                                        this.distance = -1;
                                        return;
                                    }
                                }
                            }
                            if (goalSet.contains(neighbour)) {
                                int searchtex = vertex;
                                while (edgeTo[searchtex] != -1) {
                                    searchtex = edgeTo[searchtex];
                                }
                                if (!srcSet.contains(searchtex)) {
                                    if (this.ancestor == -1) {
                                        this.distance = -1;
                                        return;
                                    }
                                }
                            }


                            // we have found the best neighbour
                            this.setPath(neighbour, vertex, vertexes);
                            return;
                        }
                        else {
                            this.setPath(neighbour, vertex, vertexes);
                        }
                    }
                }
            }
        }

        private void setPath(int item, int vertex, SET<Integer> goal) {
            int dist = 1;
            // if (vertex != source && vertex != goal) - old
            // construct path to ancestor by going reverse-order
            while (!goal.contains(vertex)) {
                vertex = edgeTo[vertex];
                dist += 1;
            }

            vertex = item;
            while (!goal.contains(vertex)) {
                vertex = edgeTo[vertex];
                dist += 1;
            }

            if (dist < this.distance) {
                // this is the common ancestor
                ancestor = item;
                this.distance = dist;
            }

        }

        public int getDistance() {
            return this.distance;
        }

        public int getAncestor() {
            return ancestor;
        }
    }


}
